const question=[
    {
        'que':'Who is the father of our nation?',
        'a':'Narendra Damodardas Modi',
        'b':'Rajnath Singh',
        'c':'Mohan Das Karam Chandar Gandhi',
        'd':'Mallikarjun Kharge',
        'answer':'c'
    },
    {
        'que':'How many colors are there in a rainbow?',
        'a':'Five',
        'b':'Seven',
        'c':'four',
        'd':'Nine',
        'answer':'b'
    },
    {
         'que':'Delhi is situated on the bank of which river?',
        'a':'Ganga',
        'b':'Kaveri',
        'c':'Narmada',
        'd':'Yamuna',
        'answer':'d'
    },
    {
        'que':'Which animal can live without drinking water for many days?',
        'a':'Cammel',
        'b':'Tiger',
        'c':'Hippo',
        'd':'Lion',
        'answer':'a'
    },
    {
        'que':'What is the National fruit of India?',
        'a':'Apple',
        'b':'Mango',
        'c':'Banana',
        'd':'Pear',
        'answer':'b'
    },
    {
        'que':'Name one famous crop of Assam?',
        'a':'Tea',
        'b':'Coffee',
        'c':'Wheat',
        'd':'Rice',
        'answer':'a'
    },
    {
        'que':'Who was the first woman Prime Minister of India?',
        'a':'Smt. Smriti Zubin Irani',
        'b':'Ms. Aditi Das Rout',
        'c':'Ms. Shalu Sharma',
        'd':'Smt. Indira Gandhi',
        'answer':'d'
    },
    {
        'que':'Name the summer capital of Jammu and Kashmir?',
        'a':'Srinagar',
        'b':'Raipur',
        'c':'Patna',
        'd':'Chandigarh',
        'answer':'a'
    },
    {
        'que':'Name the 4th planet of our solar system??',
        'a':'Venus',
        'b':'Jupiter',
        'c':'Mars',
        'd':'Neptune',
        'answer':'c'
    },
    
    {
        'que':'Name the folk dance of Assam?',
        'a':'Bharatanatyam',
        'b':'Bihu',
        'c':'Odissi',
        'd':'Kathak',
        'answer':'b'
    }
]
let index=0;
let total=question.length;
let right=0;
let wrong=0;
const quebox=document.getElementById('quebox');
const optionInputs=document.querySelectorAll('.option');
function RunQuestion()
{
    if(index === total)
    {
        return endQuiz();
    }
    reset();
    const data=question[index];
    quebox.innerText=`${index+1}) ${data.que}`;
    optionInputs[0].nextElementSibling.innerText=data.a;
    optionInputs[1].nextElementSibling.innerText=data.b;
    optionInputs[2].nextElementSibling.innerText=data.c;
    optionInputs[3].nextElementSibling.innerText=data.d;
}

function nextQues()
{
    const data=question[index];
    const ans=getAnswer();
    
    if(ans == data.answer)
    {
        right++;
    }
    else
    {
        wrong++;
    }
    index++;
    RunQuestion();
    return;
}

function getAnswer()
{
    let Ans;
    optionInputs.forEach(function (input) 
    {
        
        if(input.checked)
        {
            Ans= input.value;
        } 
    }
    ) 
    return Ans;
}
function reset()
{
    optionInputs.forEach(function (input)
    {
        input.checked=false;
    })
}
function endQuiz()
{
    document.getElementById("box").innerHTML=`
    <h3> Thank You for Playing the quiz</h3>
    <h1 class='text-success'>You Score &#127881; </h1>
    <h2>${right}/${total} are correct.</h2>`;
}
RunQuestion();